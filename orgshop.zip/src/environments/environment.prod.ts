export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA-A7T3YvT3dbd5zmAntIaDayJij5lgp-I",
    authDomain: "oshop-proj1.firebaseapp.com",
    databaseURL: "https://oshop-proj1.firebaseio.com",
    projectId: "oshop-proj1",
    storageBucket: "",
    messagingSenderId: "570513077597"
  }
};
