import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductFormComponent } from './component/product-form/product-form.component';
import { AdminProductListComponent } from './component/admin-product-list/admin-product-list.component';

@NgModule({
  declarations: [ProductFormComponent, AdminProductListComponent],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
