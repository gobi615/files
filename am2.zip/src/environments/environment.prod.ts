export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDOWJWuoGre2zhtuaDBGirG4X-YhHRqTvs",
    authDomain: "agm2-angularmeterial.firebaseapp.com",
    databaseURL: "https://agm2-angularmeterial.firebaseio.com",
    projectId: "agm2-angularmeterial",
    storageBucket: "",
    messagingSenderId: "977366170004"
  }
};
