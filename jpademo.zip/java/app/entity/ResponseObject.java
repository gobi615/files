package app.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ResponseObject {
	
	@Autowired
	public Actor[] actor;

	public Actor[] getActor() {
		return actor;
	}

	public void setActor(Actor[] actor) {
		this.actor = actor;
	}
	

}
