package app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Entity
@JsonIgnoreProperties
public class Actor {
	
	@Id
	@Column(name = "actor_id") 
	public String actorId;
	
	@Column(name = "first_name")
	public String fName;
	@Column(name = "last_name")
	public String lName;
	@Column(name = "last_update")
	public String lastUpdate;
	
	@OneToOne(mappedBy="actor")
	public FilmActor filmActor;
	
	public String getActorId() {
		return actorId;
	}
	public void setActorId(String actorId) {
		this.actorId = actorId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public FilmActor getFilmActor() {
		return filmActor;
	}
	public void setFilmActor(FilmActor filmActor) {
		this.filmActor = filmActor;
	}
	@Override
	public String toString() {
		return "Actor [actorId=" + actorId + ", fName=" + fName + ", lName=" + lName + ", lastUpdate=" + lastUpdate
				+ ", filmActor=" + filmActor + "]";
	}
	
	
}
