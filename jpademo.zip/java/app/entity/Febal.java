package app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Febal {
	
	@Id
	public String accountNo;
	
	public String ledgerBalance;

}
