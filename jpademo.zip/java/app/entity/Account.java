package app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Account {
	
	@Id
	public String accountNo;
	
	public String currencyCode;
	
	public String balance;
}
