package app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import app.entity.Account;
import app.entity.Actor;
import app.entity.ResponseObject;
import app.service.RestService;

@RestController
public class JpaRestController {
	
	@Autowired
	public RestService service;

	@PostMapping("/get")
	public ResponseObject getDetails(@RequestBody Actor actor) {
		return service.getDetails(actor);
	}
}
