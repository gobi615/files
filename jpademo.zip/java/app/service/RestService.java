package app.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import app.entity.Account;
import app.entity.Actor;
import app.entity.FilmActor;
import app.entity.ResponseObject;

@Service
public class RestService {

	@Autowired
	public EntityManager em;
	
	@Autowired 
	public ResponseObject ro;
	
	public ResponseObject getDetails(Actor actor) {
		Query q = em.createQuery("select a.actorId,a.fName, a.lName, f.fId from Actor a join a.filmActor f where a.actorId = :aid");
		List<Object[]> l = q.setParameter("aid", actor.getActorId()).getResultList();
		int i =0;
		Actor[] act = new Actor[l.size()];
		FilmActor[] fAct = new FilmActor[l.size()];
		for(Object[] o: l) {
			act[i] = new Actor();
			fAct[i] = new FilmActor();
			act[i].setFilmActor(fAct[i]);
			act[i].setActorId((String) o[0]);
			act[i].setfName((String) o[1]);
			act[i].setlName((String) o[2]);
			act[i].getFilmActor().setfId((String) o[3]);
			i++;
		}
		
		ro.setActor(act);
				
		return ro;
	}

}
