import { Component, OnInit } from '@angular/core';
import { AppUser } from 'src/app/shared/models/app-user';
import { AuthService } from 'src/app/shared/service/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  appUser: AppUser;
  constructor(private auth: AuthService) { }

  async ngOnInit() {
    this.auth.appUser$.subscribe(appUser => {
      return this.appUser = appUser;
    });
  }

  logout() {
    this.auth.logout();
  }

}
