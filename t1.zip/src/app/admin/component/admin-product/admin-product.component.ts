import { Component, OnInit } from '@angular/core';
//import { DataTableResource } from 'angular-2-data-table';
import { Product } from 'src/app/shared/models/product';
import { Subscription } from 'rxjs';
import { ProductService } from 'src/app/shared/service/product.service';

@Component({
  selector: 'app-admin-product',
  templateUrl: './admin-product.component.html',
  styleUrls: ['./admin-product.component.css']
})
export class AdminProductComponent implements OnInit {
  products: Product[];
  subscription: Subscription;
  //tableResource: DataTableResource<Product>;
  items: Product[] = [];
  itemCount: number; 

  constructor(private productService: ProductService) {
    this.subscription = this.productService.getAll().valueChanges().subscribe((products) => {
      this.products = products;
      //this.initializeTable(products);
    });
   }
/*
   private initializeTable(products: Product[]) {
    this.tableResource = new DataTableResource(products);
    this.tableResource.query({ offset: 0 })
      .then(items => this.items = items);
    this.tableResource.count()
      .then(count => this.itemCount = count);
  }*/

  ngOnInit() {
  }

}
