import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductFormComponent } from './component/product-form/product-form.component';
import { AdminProductComponent } from './component/admin-product/admin-product.component';
import { AdminOrdersComponent } from './component/admin-orders/admin-orders.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { AuthGuardService } from '../shared/service/auth-guard.service';
import { AdminAuthGuardService } from './services/admin-auth-guard.service';
import {FormsModule} from "@angular/forms";
//import { DataTableModule } from 'angular-4-data-table';
//import { DataTableModule } from 'angular-2-data-table'

@NgModule({
  declarations: [
    ProductFormComponent, 
    AdminProductComponent, 
    AdminOrdersComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    //DataTableModule,
    RouterModule.forChild([
      {
        path: 'admin/products/new',
        component : ProductFormComponent,
        canActivate : [AuthGuardService,AdminAuthGuardService]
      },
      {
        path : 'admin/products/:id',
        component : ProductFormComponent,
        canActivate : [AuthGuardService,AdminAuthGuardService]
      },
      { 
        path: 'admin/products', 
        component: AdminProductComponent,
        canActivate : [AuthGuardService,AdminAuthGuardService]
      },
      { 
        path: 'admin/orders', 
        component: AdminOrdersComponent,
        canActivate : [AuthGuardService,AdminAuthGuardService]
      }
    ])
  ],
  exports:[
   // DataTableModule
  ]
})
export class AdminModule { }
