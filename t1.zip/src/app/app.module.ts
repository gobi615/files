import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AngularFireModule} from 'angularfire2'
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';

import { CoreModule } from './core/core.module';
import { HomeComponent } from './core/home/home.component';
import { LoginComponent } from './core/login/login.component';
import { environment } from 'src/environments/environment';
import { SharedModule } from './shared/shared.module';
import { AdminModule } from './admin/admin.module';
//import { DataTableModule } from 'angular-4-data-table/src/index'

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CoreModule,
    SharedModule,
    AdminModule,
    AngularFireModule.initializeApp(environment.firebase),
    RouterModule.forRoot([
      {path: '', component : HomeComponent},
      {path: 'login', component : LoginComponent}     
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
