import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AngularFireAuthModule} from 'angularfire2/auth';
import {AngularFireDatabaseModule} from 'angularfire2/database'
import { AuthService } from './service/auth.service';
import * as firebase from 'firebase'; 
import { UserService } from './service/user.service';
import { ProductCardComponent } from './component/product-card/product-card.component';

@NgModule({
  declarations: [ProductCardComponent],
  imports: [
    CommonModule,
    AngularFireAuthModule,
    AngularFireDatabaseModule
  ],
  providers: [
    AuthService,
    UserService
  ],
  exports : [
    AngularFireAuthModule,
    AngularFireDatabaseModule,
    ProductCardComponent
  ]
})
export class SharedModule { }
