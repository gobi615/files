export const environment = {
  production: true, 
  firebase : {
    apiKey: "AIzaSyBUhgCg7RtkOeKMVK2t4QDQDdTcs5quwN8",
    authDomain: "eshop-test1.firebaseapp.com",
    databaseURL: "https://eshop-test1.firebaseio.com",
    projectId: "eshop-test1",
    storageBucket: "eshop-test1.appspot.com",
    messagingSenderId: "188414138671"
  }
};
